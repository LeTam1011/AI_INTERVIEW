from datetime import datetime, timezone

from fastapi import APIRouter, File, HTTPException, UploadFile, status
from sqlalchemy import select

from app.api.deps import CurrentUser, DbSession
from app.ai.cv_parser import MAX_UPLOAD_BYTES, parse_cv
from app.models.interview_entities import (
    Answer, CareerLevel, Evaluation, Interview, InterviewStatus, JobDescription,
    Question, Resume,
)
from app.schemas.workspace import (
    AnswerCreate, AnswerResponse, EvaluationCreate, EvaluationResponse,
    InterviewCreate, InterviewResponse, InterviewStatusUpdate,
    JobDescriptionCreate, JobDescriptionResponse, JobDescriptionUpdate,
    QuestionCreate, QuestionResponse, ResumeCreate, ResumeResponse, ResumeUpdate,
)

router = APIRouter(tags=["Interview Workspace"])


def _not_found() -> HTTPException:
    return HTTPException(status_code=404, detail="Resource not found")


# Resumes


@router.post("/resumes/upload", response_model=ResumeResponse, status_code=status.HTTP_201_CREATED)
async def upload_and_parse_resume(
    db: DbSession,
    user: CurrentUser,
    file: UploadFile = File(...),
):
    """Upload a PDF/DOCX CV, extract text, and persist a first-pass profile."""
    filename = (file.filename or "").replace("\\", "/").split("/")[-1].strip()
    if not filename:
        raise HTTPException(status_code=400, detail="A filename is required")

    content = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds the 5 MB upload limit")
    try:
        parsed = parse_cv(filename, content)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    title = filename.rsplit(".", 1)[0][:160].strip() or "Uploaded CV"
    resume = Resume(
        user_id=user.id,
        title=title,
        original_filename=filename[:255],
        raw_text=parsed.text,
        candidate_profile=parsed.profile,
    )
    db.add(resume)
    db.commit()
    db.refresh(resume)
    return resume

@router.post("/resumes", response_model=ResumeResponse, status_code=status.HTTP_201_CREATED)
def create_resume(payload: ResumeCreate, db: DbSession, user: CurrentUser):
    resume = Resume(user_id=user.id, title=payload.title.strip(), original_filename=payload.original_filename, raw_text=payload.raw_text)
    db.add(resume)
    db.commit()
    db.refresh(resume)
    return resume


@router.get("/resumes", response_model=list[ResumeResponse])
def list_resumes(db: DbSession, user: CurrentUser):
    return list(db.scalars(select(Resume).where(Resume.user_id == user.id).order_by(Resume.created_at.desc())))


@router.get("/resumes/{resume_id}", response_model=ResumeResponse)
def get_resume(resume_id: int, db: DbSession, user: CurrentUser):
    resume = db.scalar(select(Resume).where(Resume.id == resume_id, Resume.user_id == user.id))
    if resume is None:
        raise _not_found()
    return resume


@router.patch("/resumes/{resume_id}", response_model=ResumeResponse)
def update_resume(resume_id: int, payload: ResumeUpdate, db: DbSession, user: CurrentUser):
    resume = db.scalar(select(Resume).where(Resume.id == resume_id, Resume.user_id == user.id))
    if resume is None:
        raise _not_found()
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(resume, key, value.strip() if key == "title" and value else value)
    db.commit()
    db.refresh(resume)
    return resume


@router.delete("/resumes/{resume_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_resume(resume_id: int, db: DbSession, user: CurrentUser):
    resume = db.scalar(select(Resume).where(Resume.id == resume_id, Resume.user_id == user.id))
    if resume is None:
        raise _not_found()
    if db.scalar(select(Interview.id).where(Interview.resume_id == resume_id).limit(1)) is not None:
        raise HTTPException(status_code=409, detail="Resume is linked to an interview and cannot be deleted")
    db.delete(resume)
    db.commit()


# Job descriptions
@router.post("/jobs", response_model=JobDescriptionResponse, status_code=status.HTTP_201_CREATED)
def create_job(payload: JobDescriptionCreate, db: DbSession, user: CurrentUser):
    job = JobDescription(user_id=user.id, **payload.model_dump())
    job.title = job.title.strip()
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


@router.get("/jobs", response_model=list[JobDescriptionResponse])
def list_jobs(db: DbSession, user: CurrentUser):
    return list(db.scalars(select(JobDescription).where(JobDescription.user_id == user.id).order_by(JobDescription.created_at.desc())))


@router.get("/jobs/{job_id}", response_model=JobDescriptionResponse)
def get_job(job_id: int, db: DbSession, user: CurrentUser):
    job = db.scalar(select(JobDescription).where(JobDescription.id == job_id, JobDescription.user_id == user.id))
    if job is None:
        raise _not_found()
    return job


@router.patch("/jobs/{job_id}", response_model=JobDescriptionResponse)
def update_job(job_id: int, payload: JobDescriptionUpdate, db: DbSession, user: CurrentUser):
    job = db.scalar(select(JobDescription).where(JobDescription.id == job_id, JobDescription.user_id == user.id))
    if job is None:
        raise _not_found()
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(job, key, value.strip() if key == "title" and value else value)
    db.commit()
    db.refresh(job)
    return job


@router.delete("/jobs/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_job(job_id: int, db: DbSession, user: CurrentUser):
    job = db.scalar(select(JobDescription).where(JobDescription.id == job_id, JobDescription.user_id == user.id))
    if job is None:
        raise _not_found()
    if db.scalar(select(Interview.id).where(Interview.job_description_id == job_id).limit(1)) is not None:
        raise HTTPException(status_code=409, detail="Job description is linked to an interview and cannot be deleted")
    db.delete(job)
    db.commit()


# Interviews
@router.post("/interviews", response_model=InterviewResponse, status_code=status.HTTP_201_CREATED)
def create_interview(payload: InterviewCreate, db: DbSession, user: CurrentUser):
    resume = db.scalar(select(Resume).where(Resume.id == payload.resume_id, Resume.user_id == user.id))
    job = db.scalar(select(JobDescription).where(JobDescription.id == payload.job_description_id, JobDescription.user_id == user.id))
    if resume is None or job is None:
        raise HTTPException(status_code=404, detail="Resume or job description not found")
    level = payload.career_level or job.career_level
    context_snapshot = {
        "candidate_profile": resume.candidate_profile or {},
        "resume_text": resume.raw_text or "",
        "job": {
            "title": job.title,
            "company_name": job.company_name,
            "description": job.description,
            "required_skills": job.required_skills or [],
            "preferred_skills": job.preferred_skills or [],
            "responsibilities": job.responsibilities or [],
        },
        "career_level": level.value,
        "language": payload.language,
        "context_version": 1,
    }
    interview = Interview(
        user_id=user.id,
        resume_id=resume.id,
        job_description_id=job.id,
        title=payload.title.strip(),
        career_level=level,
        language=payload.language,
        context_snapshot=context_snapshot,
    )
    db.add(interview)
    db.commit()
    db.refresh(interview)
    return interview


@router.get("/interviews", response_model=list[InterviewResponse])
def list_interviews(db: DbSession, user: CurrentUser):
    return list(db.scalars(select(Interview).where(Interview.user_id == user.id).order_by(Interview.created_at.desc())))


@router.get("/interviews/{interview_id}", response_model=InterviewResponse)
def get_interview(interview_id: int, db: DbSession, user: CurrentUser):
    interview = db.scalar(select(Interview).where(Interview.id == interview_id, Interview.user_id == user.id))
    if interview is None:
        raise _not_found()
    return interview


@router.patch("/interviews/{interview_id}/status", response_model=InterviewResponse)
def update_interview_status(interview_id: int, payload: InterviewStatusUpdate, db: DbSession, user: CurrentUser):
    interview = db.scalar(select(Interview).where(Interview.id == interview_id, Interview.user_id == user.id))
    if interview is None:
        raise _not_found()
    now = datetime.now(timezone.utc)
    if payload.status == InterviewStatus.IN_PROGRESS and interview.started_at is None:
        interview.started_at = now
    if payload.status == InterviewStatus.COMPLETED:
        interview.completed_at = now
    interview.status = payload.status
    db.commit()
    db.refresh(interview)
    return interview


# Questions and answers
@router.post("/interviews/{interview_id}/questions", response_model=QuestionResponse, status_code=status.HTTP_201_CREATED)
def create_question(interview_id: int, payload: QuestionCreate, db: DbSession, user: CurrentUser):
    interview = db.scalar(select(Interview).where(Interview.id == interview_id, Interview.user_id == user.id))
    if interview is None:
        raise _not_found()
    question = Question(interview_id=interview.id, **payload.model_dump())
    db.add(question)
    db.commit()
    db.refresh(question)
    return question


@router.get("/interviews/{interview_id}/questions", response_model=list[QuestionResponse])
def list_questions(interview_id: int, db: DbSession, user: CurrentUser):
    interview = db.scalar(select(Interview).where(Interview.id == interview_id, Interview.user_id == user.id))
    if interview is None:
        raise _not_found()
    return list(db.scalars(select(Question).where(Question.interview_id == interview_id).order_by(Question.position)))


@router.post("/questions/{question_id}/answers", response_model=AnswerResponse, status_code=status.HTTP_201_CREATED)
def create_answer(question_id: int, payload: AnswerCreate, db: DbSession, user: CurrentUser):
    question = db.scalar(select(Question).join(Interview).where(Question.id == question_id, Interview.user_id == user.id))
    if question is None:
        raise _not_found()
    answer = Answer(question_id=question.id, **payload.model_dump())
    db.add(answer)
    db.commit()
    db.refresh(answer)
    return answer


@router.get("/questions/{question_id}/answers", response_model=list[AnswerResponse])
def list_answers(question_id: int, db: DbSession, user: CurrentUser):
    question = db.scalar(select(Question).join(Interview).where(Question.id == question_id, Interview.user_id == user.id))
    if question is None:
        raise _not_found()
    return list(db.scalars(select(Answer).where(Answer.question_id == question_id).order_by(Answer.created_at)))


# Evaluations (currently persisted scores/feedback; AI evaluator comes in a later phase)
@router.post("/interviews/{interview_id}/evaluations", response_model=EvaluationResponse, status_code=status.HTTP_201_CREATED)
def create_evaluation(interview_id: int, payload: EvaluationCreate, db: DbSession, user: CurrentUser):
    interview = db.scalar(select(Interview).where(Interview.id == interview_id, Interview.user_id == user.id))
    if interview is None:
        raise _not_found()
    if payload.answer_id is not None:
        answer = db.scalar(
            select(Answer).join(Question).where(
                Answer.id == payload.answer_id,
                Question.interview_id == interview_id,
            )
        )
        if answer is None:
            raise HTTPException(status_code=400, detail="Answer does not belong to this interview")
        existing = db.scalar(select(Evaluation).where(Evaluation.answer_id == payload.answer_id))
        if existing is not None:
            raise HTTPException(status_code=409, detail="This answer already has an evaluation")
    evaluation = Evaluation(interview_id=interview_id, **payload.model_dump())
    db.add(evaluation)
    db.flush()
    evaluations = list(db.scalars(select(Evaluation).where(Evaluation.interview_id == interview_id)))
    interview.overall_score = round(sum(item.total_score for item in evaluations) / len(evaluations), 2)
    db.commit()
    db.refresh(evaluation)
    return evaluation


@router.get("/interviews/{interview_id}/evaluations", response_model=list[EvaluationResponse])
def list_evaluations(interview_id: int, db: DbSession, user: CurrentUser):
    interview = db.scalar(select(Interview).where(Interview.id == interview_id, Interview.user_id == user.id))
    if interview is None:
        raise _not_found()
    return list(db.scalars(select(Evaluation).where(Evaluation.interview_id == interview_id).order_by(Evaluation.created_at)))
