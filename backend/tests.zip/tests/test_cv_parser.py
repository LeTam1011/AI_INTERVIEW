from io import BytesIO

import pytest
from docx import Document

from app.ai.cv_parser import build_candidate_profile, parse_cv


def make_docx(text: str) -> bytes:
    stream = BytesIO()
    document = Document()
    for line in text.splitlines():
        document.add_paragraph(line)
    document.save(stream)
    return stream.getvalue()


def test_docx_extracts_text_and_builds_profile():
    content = make_docx(
        "Nguyen Van A\nnguyenvana@example.com\nSkills\nJava, Spring Boot, PostgreSQL, Git\n"
        "Education\nUniversity of Da Nang\nProjects\nCafe management system"
    )
    parsed = parse_cv("resume.docx", content)
    assert "Cafe management system" in parsed.text
    assert parsed.profile["name"] == "Nguyen Van A"
    assert parsed.profile["email"] == "nguyenvana@example.com"
    assert "Java" in parsed.profile["skills"]
    assert "Spring Boot" in parsed.profile["skills"]
    assert "University of Da Nang" in parsed.profile["education_text"]


def test_rejects_unsupported_extension():
    with pytest.raises(ValueError, match="Unsupported file type"):
        parse_cv("resume.txt", b"This is a long enough text file but unsupported.")


def test_rejects_empty_file():
    with pytest.raises(ValueError, match="empty"):
        parse_cv("resume.pdf", b"")


def test_rejects_document_with_no_usable_text():
    content = make_docx("tiny")
    with pytest.raises(ValueError, match="No usable text"):
        parse_cv("resume.docx", content)


def test_profile_reports_rule_based_limitations():
    profile = build_candidate_profile("Nguyen Van A\nJava developer with Spring Boot experience")
    assert profile["extraction_method"] == "rule_based"
    assert profile["limitations"]
